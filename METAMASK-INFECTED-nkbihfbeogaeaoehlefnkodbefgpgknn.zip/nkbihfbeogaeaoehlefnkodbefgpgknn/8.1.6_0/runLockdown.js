// Freezes all intrinsics
// eslint-disable-next-line no-undef,import/unambiguous
lockdown({
  errorTaming: 'unsafe',
  mathTaming: 'unsafe',
  dateTaming: 'unsafe',
})
